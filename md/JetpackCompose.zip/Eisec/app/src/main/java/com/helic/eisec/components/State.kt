package com.helic.eisec.components

import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun Message(title: String) {
    Text(text = title)
}
