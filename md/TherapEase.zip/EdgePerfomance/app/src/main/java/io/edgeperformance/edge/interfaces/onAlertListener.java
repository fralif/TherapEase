package io.edgeperformance.edge.interfaces;

public interface onAlertListener {
    void onClickYesButton();

    void onClickNoButton();
}
