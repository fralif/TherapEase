package io.edgeperformance.edge.MorningRoutine.Models;

public class JournalM {

    private String question, id;

    public JournalM() {
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
