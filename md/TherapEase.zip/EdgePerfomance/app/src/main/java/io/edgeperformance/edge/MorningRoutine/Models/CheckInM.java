package io.edgeperformance.edge.MorningRoutine.Models;

public class CheckInM {

    private String question, id;

    public CheckInM() {
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
