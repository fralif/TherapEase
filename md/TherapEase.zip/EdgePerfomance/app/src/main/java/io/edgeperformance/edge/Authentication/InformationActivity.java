package io.edgeperformance.edge.Authentication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import io.edgeperformance.edge.R;


public class InformationActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

    }

    @Override
    public void finish() {
        super.finish();
    }
}
