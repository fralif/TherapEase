package io.edgeperformance.edge.EveningRoutine;

public class ValuesE {

    private String values;

    public ValuesE() {
    }

    public String getValues() {
        return values;
    }

    public void setValues(String values) {
        this.values = values;
    }
}
