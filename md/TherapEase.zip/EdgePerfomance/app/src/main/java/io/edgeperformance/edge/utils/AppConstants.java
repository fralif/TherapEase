package io.edgeperformance.edge.utils;

public interface AppConstants {
    String SPACE_ID = "t93gj8p4hchq";
    String API_TOKEN = "9Kni87zZOZwbbw3M_Kolg-0Jvq4CVSL7j_6cle_W5aE";

//    String SPACE_ID = "omhowcfu62ti";
//    String API_TOKEN = "h0S2ed1uUi-YHY4fFfwj8GX8ozUFoPqEgAkqLm4y2bY";


    String SESSION_KEY = "session";
    String BREATH_WORK_KEY = "breathWork";
    String MINDFULNESS_KEY = "mindfulness";
    String KEY_TAG = "key";
    String AUDIO_TAG = "audio";
}
